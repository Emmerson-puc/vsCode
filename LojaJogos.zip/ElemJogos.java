
/**
 * Classe Elemento Jogos
 */
public class ElemJogos {
    public Jogos dadosJogos;
    public ElemJogos proximo;

    public ElemJogos(Jogos dados_Jogos){
        dadosJogos = dados_Jogos;
        proximo = null;

    }
}


