

public enum testeClientes {

}
